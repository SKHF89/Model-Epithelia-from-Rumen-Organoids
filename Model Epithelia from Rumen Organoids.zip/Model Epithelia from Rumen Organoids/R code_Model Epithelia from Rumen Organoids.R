############    Start of the Code  #############

# Load necessary libraries
library(ggplot2)
library(dplyr)
library(tidyr)
library(zFPKM)
library(DESeq2)
library(clusterProfiler)
library(AnnotationHub)
library(AnnotationDbi)
library(BiocParallel)
library(enrichplot)
library(patchwork)
library(cowplot)
library(ComplexHeatmap)
library(ggrepel)
library(RColorBrewer)
library(gridExtra)
library(circlize)

# Load Sheep OrgDb from AnnotationHub
ah <- AnnotationHub()
sheep_orgdb <- ah[["AH114632"]]  # Load sheep OrgDb
print(sheep_orgdb)
cat("Number of genes in sheep_orgdb:", length(keys(sheep_orgdb)), "\n")

# ------------------------#
# Step 1: Load and Filter FPKM Data with zFPKM
# ------------------------#

# Load the FPKM data
fpkm_data <- read.csv("fpkm_rumen.csv", row.names = 1)
cat("Number of genes in original FPKM data:", nrow(fpkm_data), "\n")

# Remove invalid gene names
fpkm_data <- fpkm_data[!(fpkm_data$gene_name %in% c("-", "", NA)), ]
cat("Number of genes in FPKM data after removing invalid names:", nrow(fpkm_data), "\n")

# Extract gene names separately and process FPKM values only
gene_names_fpkm <- fpkm_data$gene_name  
fpkm_values <- fpkm_data[, -ncol(fpkm_data)]  

# Calculate zFPKM values
zFPKM_matrix <- zFPKM(as.data.frame(fpkm_values))

# Plot zFPKM distribution for visualization
zFPKM_long <- tidyr::pivot_longer(as.data.frame(zFPKM_matrix), cols = everything(), names_to = "Sample", values_to = "zFPKM")
zFPKM_long <- zFPKM_long %>% filter(is.finite(zFPKM))
p <- ggplot(zFPKM_long, aes(x = zFPKM)) +
  geom_histogram(bins = 100, fill = "blue", alpha = 0.7) +
  geom_vline(xintercept = -3, color = "red", linetype = "dashed") +  
  labs(title = "Distribution of zFPKM Values", x = "zFPKM", y = "Frequency") +
  theme_minimal()
# Save the plot as JPEG
ggsave("zFPKM_distribution.jpg", 
       plot = p,
       width = 10,  # width in inches
       height = 7,  # height in inches
       dpi = 600)   # resolution

# Apply zFPKM cutoff to select active genes
zFPKM_cutoff <- -3
active_genes <- rowSums(zFPKM_matrix > zFPKM_cutoff) > (ncol(zFPKM_matrix) / 4)
fpkm_filtered <- fpkm_values[active_genes, ]
gene_names_filtered <- gene_names_fpkm[active_genes]

# Create a named vector for gene names to ensure alignment with gene IDs
gene_names_fpkm_named <- setNames(gene_names_filtered, rownames(fpkm_filtered))

cat("Number of genes after zFPKM filtering:", nrow(fpkm_filtered), "\n")

# ------------------------#
# Step 2: Load and Filter Raw Count Data Based on zFPKM Filtering
# ------------------------#

# Load raw count data
raw_count_data <- read.csv("raw count_rumen.csv", row.names = 1)
cat("Number of genes in original raw count data:", nrow(raw_count_data), "\n")

# Filter out invalid gene names
raw_count_data <- raw_count_data[!(raw_count_data$gene_name %in% c("-", "", NA)), ]
cat("Number of genes in raw count data after removing invalid names:", nrow(raw_count_data), "\n")

# Filter raw counts based on zFPKM active genes
filtered_gene_ids <- rownames(fpkm_filtered)  # Genes that passed zFPKM filtering
raw_counts_filtered <- raw_count_data[rownames(raw_count_data) %in% filtered_gene_ids, ]
cat("Number of genes in raw count data after zFPKM filtering:", nrow(raw_counts_filtered), "\n")

# Apply additional filter based on raw count threshold
raw_counts_filtered <- raw_counts_filtered[rowSums(raw_counts_filtered[, -ncol(raw_counts_filtered)]) >= 120, ]
cat("Number of genes after applying raw count threshold:", nrow(raw_counts_filtered), "\n")

# Ensure FPKM data matches the final filtered raw counts
fpkm_final_filtered <- fpkm_filtered[rownames(fpkm_filtered) %in% rownames(raw_counts_filtered), ]

# Retrieve the final gene names for these filtered genes
gene_names_final_filtered <- gene_names_fpkm_named[rownames(fpkm_final_filtered)]

# Check if the lengths of final filtered data match
cat("Number of genes in final filtered FPKM data:", nrow(fpkm_final_filtered), "\n")
cat("Number of genes in final filtered raw count data:", nrow(raw_counts_filtered), "\n")

# Save final filtered FPKM data with gene names
fpkm_final_filtered$gene_name <- gene_names_final_filtered
write.csv(fpkm_final_filtered, "final_filtered_fpkm_values_with_gene_names.csv", row.names = TRUE)
write.csv(raw_counts_filtered, "filtered_raw_counts.csv", row.names = TRUE)

# ------------------------#
# Step 3: DESeq2 Analysis on Filtered Raw Counts
# ------------------------#

# Remove gene names for DESeq2 analysis, as they are not required
raw_counts_filtered <- raw_counts_filtered[, -ncol(raw_counts_filtered)]

# Define experimental conditions for DESeq2
conditions <- factor(c(rep("primary-insert", 4), rep("organoid-insert", 4), rep("tissue", 4)))
col_data <- data.frame(condition = conditions)
rownames(col_data) <- colnames(raw_counts_filtered)

# Create DESeq2 dataset and perform analysis
dds <- DESeqDataSetFromMatrix(countData = raw_counts_filtered, colData = col_data, design = ~ condition)
dds <- DESeq(dds)

# Retrieve DESeq2 results for each comparison
res_primary_insert_vs_tissue <- results(dds, contrast = c("condition", "primary-insert", "tissue"), pAdjustMethod = "BH")
res_organoid_insert_vs_tissue <- results(dds, contrast = c("condition", "organoid-insert", "tissue"), pAdjustMethod = "BH")
res_primary_insert_vs_organoid_insert <- results(dds, contrast = c("condition", "primary-insert", "organoid-insert"), pAdjustMethod = "BH")

# Convert DESeq2 results to data frames and save
res_primary_insert_vs_tissue_df <- as.data.frame(res_primary_insert_vs_tissue)
res_organoid_insert_vs_tissue_df <- as.data.frame(res_organoid_insert_vs_tissue)
res_primary_insert_vs_organoid_insert_df <- as.data.frame(res_primary_insert_vs_organoid_insert)

cat("Number of genes in DESeq2 results (PC vs tissue):", nrow(res_primary_insert_vs_tissue_df), "\n")
cat("Number of genes in DESeq2 results (Orga vs tissue):", nrow(res_organoid_insert_vs_tissue_df), "\n")
cat("Number of genes in DESeq2 results (PC vs Orga):", nrow(res_primary_insert_vs_organoid_insert_df), "\n")

# ------------------------#
# Step 4: Prepare VST-Transformed Data for Downstream Analysis
# ------------------------#

# Perform variance-stabilizing transformation
vst_data <- vst(dds, blind = FALSE)

# Use vst_data for further analysis, correlation studies, and plotting
cat("VST data ready for downstream analysis.\n")

# Save VST-transformed data for use in other scripts or analyses
vst_counts <- assay(vst_data)
write.csv(vst_counts, "vst_transformed_counts.csv", row.names = TRUE)


# ================================================== #
# COMPLETE GSEA ANALYSIS AND VISUALIZATION WORKFLOW
# ================================================== #

# Set global options
options(ggrepel.max.overlaps = Inf)

# ========================= #
# 1. CORE FUNCTION DEFINITIONS
# ========================= #

# Function to run individual GSEA with proper simplification sequence
run_individual_gsea <- function(gene_list, analysis_type, ont = NULL) {
  if (is.null(gene_list) || length(gene_list) == 0) {
    message(sprintf("Invalid gene list provided for %s analysis", analysis_type))
    return(NULL)
  }
  
  tryCatch({
    message(sprintf("\nStarting %s analysis...", analysis_type))
    
    result <- gseGO(
      geneList = jitter(gene_list, factor = 1e-10),
      OrgDb = sheep_orgdb,
      keyType = "ENTREZID",
      ont = ont,
      minGSSize = 6,
      maxGSSize = 500,
      pvalueCutoff = 0.05,
      pAdjustMethod = "BH",
      eps = 0,
      BPPARAM = SnowParam(exportglobals = FALSE)
    )
    
    # Simplify GO results
    if (!is.null(result) && nrow(result@result) > 0) {
      message(sprintf("Simplifying %s pathways...", analysis_type))
      result <- clusterProfiler::simplify(result,
                                          cutoff = 0.7,
                                          by = "p.adjust",
                                          select_fun = min,
                                          measure = "Wang",
                                          semData = NULL)
    }
    
    if (is.null(result) || nrow(result@result) == 0) {
      message(sprintf("No enrichment found for %s analysis", analysis_type))
      return(NULL)
    }
    
    message(sprintf("Found %d enriched terms for %s analysis", nrow(result@result), analysis_type))
    return(result)
    
  }, error = function(e) {
    message(sprintf("Error in %s analysis: %s", analysis_type, e$message))
    return(NULL)
  })
}


# Function to select balanced pathways
select_balanced_pathways <- function(gsea_result) {
  if(is.null(gsea_result)) {
    message("No GSEA result provided")
    return(NULL)
  }
  
  if(nrow(gsea_result@result) == 0) {
    message("No significant pathways found")
    return(NULL)
  }
  
  tryCatch({
    result_df <- as.data.frame(gsea_result@result)
    
    # Print before filtering
    message("Pathways before filtering:")
    print(result_df$Description)
    
    # Base exclusion pattern
    exclude_pattern <- paste(
      "\\b(external encapsulating structure|extracellular space|mitochondrial protein-containing complex|ribonucleoprotein complex|Folate|COVID|group of donors|Staphylo|Diabetic|Parkinson|papilloma|",
      "Malaria|fatty liver|Huntington|muscle|cytomegalo|diabetic|Drug|",
      "carcinoma|arthritis|cancer|carcinogenesis|cardio|virus|Axon|Viral|viral|",
      "xenobiotics|Relaxin|Steroid|disease|Disease|Alzheimer|Tuberculosis|", 
      "lupus|polysaccharide|MHC|Platelet|antigen|Intestinal|IgA|Th1|Th17|",
      "Allograft|Toxoplasmosis|toxoplasmosis|Insulin|insulin|secretion|plasmosis|Yersinia|infection)\\b",
      sep=""
    )
    
    # Filter pathways
    initial_count <- nrow(result_df)
    result_df <- result_df[!grepl(exclude_pattern, result_df$Description), ]
    # Print after filtering
    message("Pathways after filtering:")
    print(result_df$Description)
    
    message(sprintf("Filtered out %d pathways based on exclusion criteria", initial_count - nrow(result_df)))
    
    if(nrow(result_df) == 0) {
      message("No pathways remaining after filtering")
      return(NULL)
    }
    
    # Split into activated and suppressed pathways
    activated <- result_df[result_df$NES > 0, ]
    suppressed <- result_df[result_df$NES < 0, ]
    
    message("\nInitial pathway counts:")
    message(sprintf("Activated pathways: %d", nrow(activated)))
    message(sprintf("Suppressed pathways: %d", nrow(suppressed)))
    
    # Calculate balanced selection
    n_activated <- min(3, nrow(activated))
    n_suppressed <- min(3, nrow(suppressed))
    
    # Adjust counts for imbalanced cases
    if(n_activated < 3 && nrow(suppressed) > 3) {
      n_suppressed <- min(5 - n_activated, nrow(suppressed))
    }
    if(n_suppressed < 3 && nrow(activated) > 3) {
      n_activated <- min(5 - n_suppressed, nrow(activated))
    }
    
    message("\nFinal selection:")
    message(sprintf("Selected activated pathways: %d", n_activated))
    message(sprintf("Selected suppressed pathways: %d", n_suppressed))
    
    selected_activated <- head(activated$ID, n_activated)
    selected_suppressed <- head(suppressed$ID, n_suppressed)
    
    return(c(selected_activated, selected_suppressed))
    
  }, error = function(e) {
    message(sprintf("Error in pathway selection: %s", e$message))
    return(NULL)
  })
}

# Function to check and validate gene list
validate_gene_list <- function(gene_list, name = "") {
  if(is.null(gene_list)) {
    message(sprintf("Gene list %sis NULL", ifelse(name == "", "", paste(name, " "))))
    return(FALSE)
  }
  
  if(length(gene_list) == 0) {
    message(sprintf("Gene list %sis empty", ifelse(name == "", "", paste(name, " "))))
    return(FALSE)
  }
  
  if(is.null(names(gene_list))) {
    message(sprintf("Gene list %slacks names", ifelse(name == "", "", paste(name, " "))))
    return(FALSE)
  }
  
  return(TRUE)
}

# Function to check directory structure
check_and_create_dirs <- function() {
  tryCatch({
    dir.create("GSEA_Results", showWarnings = FALSE)
    dir.create(file.path("GSEA_Results", "Plots"), showWarnings = FALSE)
    dir.create(file.path("GSEA_Results", "Data"), showWarnings = FALSE)
    message("Directory structure created successfully")
    return(TRUE)
  }, error = function(e) {
    message(sprintf("Error creating directory structure: %s", e$message))
    return(FALSE)
  })
}

# ========================= #
# 2. PATHWAY ANALYSIS AND RESULTS SAVING FUNCTIONS
# ========================= #

# Function to save detailed pathway information 
save_pathway_details <- function(gsea_result, type, comparison, output_dir = ".") {
  if(is.null(gsea_result)) {
    message(sprintf("No GSEA result provided for %s %s", type, comparison))
    return(NULL)
  }
  
  if(nrow(gsea_result@result) == 0) {
    message(sprintf("No enriched pathways found for %s %s", type, comparison))
    return(NULL)
  }
  
  tryCatch({
    # Create main results dataframe
    main_results <- as.data.frame(gsea_result@result)
    
    # Create detailed gene info with error checking for each pathway
    gene_details_list <- lapply(1:nrow(main_results), function(i) {
      pathway_id <- main_results$ID[i]
      
      if(is.null(main_results$core_enrichment[i]) || 
         is.na(main_results$core_enrichment[i]) || 
         main_results$core_enrichment[i] == "") {
        message(sprintf("Warning: No core enrichment genes for pathway %s", pathway_id))
        return(NULL)
      }
      
      tryCatch({
        core_genes <- strsplit(main_results$core_enrichment[i], "/")[[1]]
        
        # Check if gene names are available
        gene_names <- gene_names_fpkm_named[core_genes]
        if(all(is.na(gene_names))) {
          message(sprintf("Warning: No gene names found for pathway %s", pathway_id))
        }
        
        data.frame(
          Pathway_ID = pathway_id,
          Pathway_Name = main_results$Description[i],
          Gene_ID = core_genes,
          Gene_Name = gene_names,
          NES = main_results$NES[i],
          pvalue = main_results$pvalue[i],
          p.adjust = main_results$p.adjust[i],
          qvalue = main_results$qvalue[i],
          Leading_Edge = main_results$leading_edge[i],
          stringsAsFactors = FALSE
        )
      }, error = function(e) {
        message(sprintf("Error processing pathway %s: %s", pathway_id, e$message))
        return(NULL)
      })
    })
    
    # Remove NULL entries and combine results
    gene_details <- do.call(rbind, Filter(Negate(is.null), gene_details_list))
    
    if(is.null(gene_details) || nrow(gene_details) == 0) {
      message(sprintf("No valid gene details to save for %s %s", type, comparison))
      return(NULL)
    }
    
    # Create directory if it doesn't exist
    dir.create(file.path(output_dir, "GSEA_Results", "Data"), recursive = TRUE, showWarnings = FALSE)
    
    # Save files
    filename_base <- file.path(output_dir, "GSEA_Results", "Data", 
                               paste0("GSEA_", type, "_", comparison))
    
    write.csv(main_results, paste0(filename_base, "_pathway_summary.csv"), row.names = FALSE)
    write.csv(gene_details, paste0(filename_base, "_gene_details.csv"), row.names = FALSE)
    
    message(sprintf("Saved detailed results for %s %s", type, comparison))
    
    # Return results invisibly
    return(invisible(list(
      summary = main_results,
      details = gene_details,
      stats = list(
        total_pathways = nrow(main_results),
        total_genes = length(unique(gene_details$Gene_ID)),
        named_genes = sum(!is.na(gene_details$Gene_Name))
      )
    )))
    
  }, error = function(e) {
    message(sprintf("Error saving pathway details for %s %s: %s", type, comparison, e$message))
    return(NULL)
  })
}

# Function to analyze genes in pathways 
analyze_gsea_genes <- function(gsea_result, pathway_id, geneList) {
  if(!validate_gene_list(geneList)) return(NULL)
  
  tryCatch({
    idx <- which(gsea_result@result$ID == pathway_id)
    if(length(idx) == 0) {
      message(sprintf("Pathway %s not found in results", pathway_id))
      return(NULL)
    }
    
    message("\n=== ANALYZING GSEA PATHWAY GENES ===")
    message(sprintf("Pathway: %s", pathway_id))
    message(sprintf("Description: %s", gsea_result@result$Description[idx]))
    message(sprintf("SetSize: %d", gsea_result@result$setSize[idx]))
    
    # Get and validate core enrichment genes
    if(is.null(gsea_result@result$core_enrichment[idx]) || 
       is.na(gsea_result@result$core_enrichment[idx])) {
      message("No core enrichment genes found")
      return(NULL)
    }
    
    core_genes <- strsplit(gsea_result@result$core_enrichment[idx], "/")[[1]]
    
    # Get genes in ranked list
    ranked_genes <- names(geneList)
    genes_in_analysis <- intersect(core_genes, ranked_genes)
    
    if (length(genes_in_analysis) == 0) {
      message("No genes found in analysis")
      return(NULL)
    }
    
    fc_values <- geneList[genes_in_analysis]
    sorted_idx <- order(abs(fc_values), decreasing = TRUE)
    sorted_genes <- genes_in_analysis[sorted_idx]
    sorted_fc <- fc_values[sorted_idx]
    
    # Calculate and display gene statistics
    message("\nGene Statistics:")
    message(sprintf("Total genes in pathway: %d", length(core_genes)))
    message(sprintf("Genes found in ranked list: %d", length(genes_in_analysis)))
    
    
    message("\nGenes ordered by absolute fold change:")
    for(i in seq_along(sorted_genes)) {
      message(sprintf("%s (%s): %.3f", 
                      sorted_genes[i],
                      gene_names_fpkm_named[sorted_genes[i]],
                      sorted_fc[i]))
    }
    
    # Return detailed results
    return(invisible(list(
      genes = sorted_genes,
      fold_changes = sorted_fc,
      gene_names = gene_names_fpkm_named[sorted_genes],
      stats = list(
        total_genes = length(core_genes),
        found_genes = length(genes_in_analysis),
        max_fc = max(abs(sorted_fc)),
        min_fc = min(abs(sorted_fc))
      )
    )))
    
  }, error = function(e) {
    message(sprintf("Error analyzing genes for pathway %s: %s", pathway_id, e$message))
    return(NULL)
  })
}

# ========================= #
# 3. VISUALIZATION FUNCTIONS
# ========================= #
# Helper function to merge GSEA results while preserving activation status
merge_gsea_results <- function(gsea_list) {
  # Combine all results into a single data frame
  result_df <- do.call(rbind, lapply(names(gsea_list), function(name) {
    result <- gsea_list[[name]]@result
    result$Comparison <- name
    result$.sign <- ifelse(result$NES > 0, "Activated", "Suppressed")
    result
  }))
  
  # Create a new gseaResult object with the combined results
  merged <- gsea_list[[1]]
  merged@result <- result_df
  return(merged)
}

# Function to create cnetplots
create_cnetplot <- function(gsea_result, title, gene_list) {
  if(is.null(gsea_result)) {
    message(sprintf("No GSEA results available for %s", title))
    return(NULL)
  }
  
  if(nrow(gsea_result@result) == 0) {
    message(sprintf("No enriched pathways found for %s", title))
    return(NULL)
  }
  
  tryCatch({
    selected_paths <- select_balanced_pathways(gsea_result)
    if(is.null(selected_paths)) {
      message(sprintf("No pathways selected for cnetplot: %s", title))
      return(NULL)
    }
    
    # Print pathway info
    message(sprintf("\nSelected pathways for %s:", title))
    result_df <- as.data.frame(gsea_result)
    selected_df <- result_df[result_df$ID %in% selected_paths, ]
    print(selected_df[, c("ID", "Description", "setSize", "NES")])
    
    # Analyze genes for each pathway
    message("\nAnalyzing genes in pathways:")
    for(path_id in selected_paths) {
      analyze_gsea_genes(gsea_result, path_id, gene_list)
    }
    
    # Make gene IDs readable
    result_readable <- setReadable(gsea_result, OrgDb = sheep_orgdb, 'ENTREZID')
    result_subset <- result_readable
    result_subset@result <- result_readable@result[result_readable@result$ID %in% selected_paths, ]
    
    # === Dynamically set color scale limits using percentiles ===
    fc_vals <- gene_list[is.finite(gene_list)]
    fc_lower <- quantile(fc_vals, 0.05)
    fc_upper <- quantile(fc_vals, 0.95)
    
    # Safety fallback if too narrow range
    if ((fc_upper - fc_lower) < 1) {
      fc_lower <- min(fc_vals)
      fc_upper <- max(fc_vals)
    }
    
    
    # Create plot
    p <- cnetplot(result_subset,
                  node_label = "all",
                  showCategory = length(selected_paths),
                  cex.params = list(
                    gene_node = 0.4,
                    category_label = 1.2,
                    gene_label = 0.4
                  ),
                  max.overlaps = Inf,
                  layout = "dh",
                  node.shape = "sphere",
                  edge.width = 0.5,
                  node.color.alpha = 0.7,
                  color.params = list(foldChange = gene_list)) +
      scale_color_gradient2(
        low = "blue",mid = "white",high = "red",midpoint = 0,
        limits = c(fc_lower, fc_upper),
        oob = scales::squish,
        name = "Log2 Fold Change"
      ) +
      guides(
        size = guide_legend(title = "Term Size", order=1),  # Set size legend title
        color=guide_colorbar(title = "Log2 Fold Change", order = 2)
      )+
      theme(legend.position = "right",
            legend.title = element_text(size = 17, face = "bold"),   # Title font
            legend.text = element_text(size = 17),                   # Number font
            plot.title = element_text(size = 17, face = "bold", hjust = 0.5),
            plot.title.position = "plot"
      )+
      ggtitle(title)
    
    return(p)
    
  }, error = function(e) {
    message(sprintf("Error creating cnetplot for %s: %s", title, e$message))
    return(NULL)
  })
}

# Function to save cnetplots 
save_cnetplot <- function(plot, filename) {
  if(is.null(plot)) {
    message(sprintf("No plot to save for %s", filename))
    return(FALSE)
  }
  
  tryCatch({
    plot_path <- file.path("GSEA_Results", "Plots", filename)
    jpeg(plot_path, width = 6000, height = 8000, res = 600)
    print(plot)
    dev.off()
    message(sprintf("Saved cnetplot: %s", plot_path))
    print(plot)  # Display in R
    return(TRUE)
  }, error = function(e) {
    message(sprintf("Error saving cnetplot %s: %s", filename, e$message))
    return(FALSE)
  })
}

# ========================= #
# 4. ANALYSIS EXECUTION
# ========================= #
# Create directory structure
check_and_create_dirs()

# ------------------------#
# PREPARE DEG-BASED GENE LISTS FOR GSEA
# ------------------------#
message("\n=== Preparing DEG-Based Gene Lists for GSEA ===")

# Function to filter DEGs
filter_degs <- function(res, comparison_name, padj_cutoff = 0.05, log2fc_cutoff = 1) {
  filtered_res <- as.data.frame(res) %>%
    filter(!is.na(padj) & padj < padj_cutoff & abs(log2FoldChange) > log2fc_cutoff)
  
  # Create gene list directly matching your correlation approach
  gene_list <- filtered_res$log2FoldChange
  names(gene_list) <- rownames(filtered_res)
  gene_list <- sort(gene_list, decreasing = TRUE)
  
  message(sprintf("\nDEG Analysis for %s:", comparison_name))
  message(sprintf("Number of significant DEGs (padj < %s, |log2FC| > %s): %d", 
                  padj_cutoff, log2fc_cutoff, length(gene_list)))
  
  return(gene_list)
}

# Prepare gene lists for each comparison
geneList_primary_insert_vs_tissue_deg <- filter_degs(res_primary_insert_vs_tissue, "PC vs tissue")
geneList_organoid_insert_vs_tissue_deg <- filter_degs(res_organoid_insert_vs_tissue, "Orga vs tissue")
geneList_primary_insert_vs_organoid_insert_deg <- filter_degs(res_primary_insert_vs_organoid_insert, "PC vs Orga")

# ================================================== #
# DEG-BASED GSEA ANALYSIS AND VISUALIZATION WORKFLOW
# ================================================== #
message("\n=== Running DEG-Based GSEA Analyses ===")

# CC analyses for DEGs
message("\nRunning CC analyses for DEGs...")
gsea_CC_primary_insert_tissue_deg <- run_individual_gsea(geneList_primary_insert_vs_tissue_deg, "GO", "CC")
gsea_CC_organoid_insert_tissue_deg <- run_individual_gsea(geneList_organoid_insert_vs_tissue_deg, "GO", "CC")
gsea_CC_primary_insert_organoid_insert_deg <- run_individual_gsea(geneList_primary_insert_vs_organoid_insert_deg, "GO", "CC")

# Save CC results for DEGs
save_pathway_details(gsea_CC_primary_insert_tissue_deg, "CC_DEG", "primary-insert_vs_tissue")
save_pathway_details(gsea_CC_organoid_insert_tissue_deg, "CC_DEG", "organoid-insert_vs_tissue")
save_pathway_details(gsea_CC_primary_insert_organoid_insert_deg, "CC_DEG", "primary-insert_vs_organoid-insert")

# Create lists for merging results
message("\nPreparing DEG-based result lists for visualization...")

# Create original lists for DEG-based results
gsea_list_CC_deg <- list(
  "primary-insert_vs_tissue" = gsea_CC_primary_insert_tissue_deg,
  "organoid-insert_vs_tissue" = gsea_CC_organoid_insert_tissue_deg,
  "primary-insert_vs_organoid-insert" = gsea_CC_primary_insert_organoid_insert_deg
)

# Create visualizations
message("\n=== Creating DEG-Based Visualizations ===")

# Create and save cnetplots
message("\nCreating DEG-based cnetplots...")

# CC cnetplots
message("\nProcessing DEG-based CC cnetplots...")
p_cnet_CC_primary_insert_tissue_deg <- create_cnetplot(gsea_CC_primary_insert_tissue_deg, "GSEA_DEG_cellular component primary-inserts vs tissue", geneList_primary_insert_vs_tissue_deg)
p_cnet_CC_organoid_insert_tissue_deg <- create_cnetplot(gsea_CC_organoid_insert_tissue_deg, "GSEA_DEG_cellular component organoid-inserts vs tissue", geneList_organoid_insert_vs_tissue_deg)
p_cnet_CC_primary_insert_organoid_insert_deg <- create_cnetplot(gsea_CC_primary_insert_organoid_insert_deg, "GSEA_DEG_cellular component primary-inserts vs organoid-inserts", geneList_primary_insert_vs_organoid_insert_deg)

save_cnetplot(p_cnet_CC_primary_insert_tissue_deg, "GSEA_DEG_cnetplot_CC_primary-insert_vs_tissue.jpeg")
save_cnetplot(p_cnet_CC_organoid_insert_tissue_deg, "GSEA_DEG_cnetplot_CC_organoid-insert_vs_tissue.jpeg")
save_cnetplot(p_cnet_CC_primary_insert_organoid_insert_deg, "GSEA_DEG_cnetplot_CC_primary-insert_vs_organoid-insert.jpeg")

message("\nAll DEG-based analyses and visualizations complete!")

message("\nAll analyses and visualizations complete!")
message("Results have been saved in the GSEA_Results directory")

# ========================= #
# PCA Plot Analysis 
# ========================= #

# Create directory for plots 
dir.create("Visualization_Results", showWarnings = FALSE)
dir.create("Visualization_Results/PCA", showWarnings = FALSE)

# PCA Plot function 
create_pca_plot <- function(dds) {
  tryCatch({
    vsd <- vst(dds, blind=FALSE)
    pcaData <- plotPCA(vsd, intgroup="condition", returnData=TRUE)
    percentVar <- round(100 * attr(pcaData, "percentVar"))
    
    pca_plot <- ggplot(pcaData, aes(x=PC1, y=PC2, color=condition, label=name)) +
      geom_point(size=6, alpha=0.8) +
      geom_text_repel(
        size=6,
        box.padding = 1.5,
        point.padding = 0.7,
        force = 12,
        max.overlaps = Inf
      ) +
      scale_color_brewer(palette="Set1") +
      scale_x_continuous(
        breaks = scales::pretty_breaks(n = 12),
        limits = function(x) c(floor(min(x)), ceiling(max(x)))
      ) +
      scale_y_continuous(
        breaks = scales::pretty_breaks(n = 12),
        limits = function(x) c(floor(min(x)), ceiling(max(x)))
      ) +
      labs(
        title="Principal Component Analysis",
        subtitle=paste0("Total Variance Explained: ", sum(percentVar[1:2]), "%"),
        x=paste0("PC1 (", percentVar[1], "% variance)"),
        y=paste0("PC2 (", percentVar[2], "% variance)"),
        color="Condition"
      ) +
      guides(color = guide_legend(override.aes = list(alpha = 1))) +
      theme_minimal() +
      theme(
        plot.title = element_text(size=24, face="bold", hjust=0.5),
        plot.subtitle = element_text(size=18, hjust=0.5),
        axis.title = element_text(size=20, face="bold"),
        axis.text = element_text(size=16),
        legend.title = element_text(size=18, face="bold"),
        legend.text = element_text(size=16),
        legend.position = "right",
        panel.grid.major = element_line(color="grey90"),
        panel.grid.minor = element_line(color="grey95")
      )
    
    ggsave(file.path("Visualization_Results", "PCA", "PCA_plot.jpg"),
           pca_plot, width = 12, height = 8, dpi = 600)
    return(pca_plot)
  }, error = function(e) {
    message("Error in PCA plot creation: ", e$message)
    return(NULL)
  })
}

message("\n=== Creating Visualizations PCA and Volcano Plots===")

pca_plot <- create_pca_plot(dds)

comparisons <- list(
  c("primary-insert", "tissue"),
  c("organoid-insert", "tissue"),
  c("primary-insert", "organoid-insert")
)

# ========================= #
# Heatmap Analysis 
# ========================= #

# Load required libraries
library(ComplexHeatmap)
library(circlize)  # For colorRamp2
library(grid)      # For gpar and unit functions

# Create output directory
dir.create("Visualization_Results/Heatmap", recursive = TRUE, showWarnings = FALSE)

# -------- Global Range for log2(FPKM) heatmap --------
calculate_global_fpkm_range <- function(gene_lists, fpkm_data, gene_names) {
  all_values <- c()
  for (list_name in names(gene_lists)) {
    genes_to_match <- toupper(gene_lists[[list_name]])
    matched_ids <- names(gene_names)[toupper(gene_names) %in% genes_to_match]
    if (length(matched_ids) > 0) {
      fpkm_subset <- fpkm_data[matched_ids, 1:(ncol(fpkm_data) - 1), drop = FALSE]
      log2_values <- log2(as.matrix(fpkm_subset) + 1)
      all_values <- c(all_values, as.vector(log2_values))
    }
  }
  if (length(all_values) == 0) stop("No matching genes found in the data")
  
  # === Percentile-based dynamic limits ===
  fc_lower <- quantile(all_values, 0.02, na.rm = TRUE)
  fc_upper <- quantile(all_values, 0.98, na.rm = TRUE)
  
  # Safety fallback if range is too narrow
  if ((fc_upper - fc_lower) < 1) {
    fc_lower <- min(all_values, na.rm = TRUE)
    fc_upper <- max(all_values, na.rm = TRUE)
  }
  
  message(sprintf("Dynamic range: %.2f to %.2f", fc_lower, fc_upper))  # Optional: comment out if verbose
  return(list(min = fc_lower, max = fc_upper))
}


# -------- Function: log2(FPKM) heatmap --------
create_log2fpkm_heatmap <- function(genes_of_interest, filename_prefix, global_range) {
  tryCatch({
    matched_ids <- names(gene_names_fpkm_named)[toupper(gene_names_fpkm_named) %in% toupper(genes_of_interest)]
    if (length(matched_ids) == 0) {
      message(sprintf("No matching genes found for %s", filename_prefix))
      return(NULL)
    }
    
    fpkm_with_pseudo <- fpkm_final_filtered[matched_ids, 1:(ncol(fpkm_final_filtered) - 1)] + 1
    expr_data <- log2(as.matrix(fpkm_with_pseudo))
    # Reorder genes manually for selected heatmaps
    if (filename_prefix %in% c("Stratum Spinosum_log2", "Tight Junctions_log2", "Macrophages & T cells_log2","SCFA Absorption_log2")) {
      ordered_genes <- genes_of_interest[
        toupper(genes_of_interest) %in% toupper(gene_names_fpkm_named[matched_ids])
      ]
      expr_data <- expr_data[
        match(toupper(ordered_genes), toupper(gene_names_fpkm_named[matched_ids])), , drop = FALSE
      ]
      rownames(expr_data) <- ordered_genes
    } else {
      # Default rownames if no manual order
      rownames(expr_data) <- gene_names_fpkm_named[matched_ids]
    }
    
    conditions <- factor(c(rep("primary-insert", 4), rep("organoid-insert", 4), rep("tissue", 4)),levels = c("primary-insert", "organoid-insert", "tissue"))
    
    ha <- HeatmapAnnotation(
      condition = conditions,
      col = list(condition = c(
        "primary-insert" = "#E41A1C",
        "organoid-insert" = "#4DAF4A",
        "tissue" = "#377EB8"
      )),
      show_annotation_name = FALSE,
      annotation_legend_param = list(
        title_gp = gpar(fontsize = 20),
        labels_gp = gpar(fontsize = 20)
      )
    )
    
    ht <- Heatmap(
      expr_data,
      name = "log2(FPKM)",
      col = colorRamp2(
        c(global_range$min, (global_range$min + global_range$max)/2, global_range$max),
        c("blue", "white", "red")
      ),
      cluster_rows = FALSE,
      cluster_columns = FALSE,
      show_row_names = TRUE,
      row_names_gp = gpar(fontsize = 20),
      column_names_gp = gpar(fontsize = 20),
      top_annotation = ha,
      height = unit(20, "cm"),
      width = unit(25, "cm"),
      heatmap_legend_param = list(
        title_gp = gpar(fontsize = 20),
        labels_gp = gpar(fontsize = 20),
        legend_height = unit(8, "cm"),
        grid_width = unit(2, "cm")
      )
    )
    
    jpeg(file.path("Visualization_Results", "Heatmap", 
                   paste0(filename_prefix, "_log2fpkm_heatmap.jpg")),
         width = 9200, height = 9200, res = 600)
    draw(ht, padding = unit(c(4, 16, 4, 16), "cm"))
    dev.off()
  }, error = function(e) {
    message(sprintf("Error processing log2 heatmap for %s: %s", filename_prefix, e$message))
  })
}

# -------- Define gene lists --------
gene_lists <- list(
  "Stratum Basale"=c("COL17A1", "SYNE2", "FABP5", "UHRF1", "HELLS", "KRT5", "KRT14"),
  "Stratum Spinosum"=c("CA1", "CA12", "ACAA2","KRT15", "KRT17","S100A9", "S100A12", "BDH1", "TST", "LYPD3", "YBX1"),
  "Differentiating Keratinocytes"=c("FABP5", "KRTDAP", "SPINK5", "CSTA", "GSTA1", "IGF2", "PI3", "TFF3", "RBP2", "MGST1"),
  "Highly Differentiated Keratinocyes"=c( "CNFN","KRT23", "CAST","ANXA1", "RPS2", "RPL8", "AHNAK", "DSP", "DSTN"),
  "Tight Junctions"=c("CLDN1", "CLDN4", "CLDN6", "CLDN7", "TJP1", "TJP2", "TJP3"),
  "Fibroblasts"=c("COL3A1", "COL1A1","LOXL1","FN1","VIM","TNC","POSTN","DCN", "MFAP5","PDGFRA","PDGFRB"),
  "Endothelials"=c("PECAM1","CDH5","CLDN5"),
  "Macrophages & T cells"=c("CD4","CD69","C1QA","C1QB","C1QC"),
  "SCFA Absorption"=c("SLC9A1","SLC9A3","SLC16A1","SLC16A3","SLC26A3","SLC26A6","ATP1A1","ATP6V1A","SLC5A8","SLC4A2","SLCO2A1")
)

# -------- Run all heatmaps --------
global_fpkm_range <- calculate_global_fpkm_range(gene_lists, fpkm_final_filtered, gene_names_fpkm_named)

for (name in names(gene_lists)) {
  local_range <- calculate_global_fpkm_range(
    gene_lists = list(temp = gene_lists[[name]]),
    fpkm_data = fpkm_final_filtered,
    gene_names = gene_names_fpkm_named
  )
  create_log2fpkm_heatmap(gene_lists[[name]], paste0(name, "_log2"), local_range)
}

# ========================= #
# DEG HEATMAPS (PATHWAY-GROUPED)
# ========================= #

# Load required libraries
library(DESeq2)
library(ComplexHeatmap)
library(circlize)
library(dplyr)
library(tibble)

#----------------------------
# Load FPKM matrix and process
#----------------------------
fpkm <- read.csv("final_filtered_fpkm_values_with_gene_names.csv", row.names = 1, check.names = FALSE)
fpkm$gene_name <- toupper(fpkm$gene_name)

# Load GSEA gene details and filter
gsea_path <- file.path("GSEA_Results", "Data", "GSEA_CC_DEG_primary-insert_vs_organoid-insert_gene_details.csv")
gsea <- read.csv(gsea_path)
gsea <- gsea[!grepl("ribonucleoprotein complex|plasma membrane", gsea$Pathway_Name, ignore.case = TRUE), ]
gsea$Gene_Name <- toupper(gsea$Gene_Name)

# Filter and align
gene_list <- unique(gsea$Gene_Name)
fpkm_filtered <- fpkm[fpkm$gene_name %in% gene_list, ]
fpkm_filtered <- fpkm_filtered[!duplicated(fpkm_filtered$gene_name), ]
rownames(fpkm_filtered) <- fpkm_filtered$gene_name
fpkm_filtered <- fpkm_filtered[, !colnames(fpkm_filtered) %in% "gene_name"]

gene_pathway_map <- gsea[gsea$Gene_Name %in% rownames(fpkm_filtered), c("Gene_Name", "Pathway_Name")]
gene_pathway_map <- gene_pathway_map[!duplicated(gene_pathway_map$Gene_Name), ]
write.csv(gene_pathway_map, file = "Genes_in_pathways_PC_vs_Orga.csv", row.names = FALSE)

# Z-score on log2(FPKM)
expr_matrix <- log2(as.matrix(fpkm_filtered) + 1)
zscore_matrix <- t(scale(t(expr_matrix)))
zscore_matrix <- zscore_matrix[gene_pathway_map$Gene_Name, ]
row_group <- gene_pathway_map$Pathway_Name
names(row_group) <- gene_pathway_map$Gene_Name

# Reorder pathway levels
desired_order <- c("ribosome", "cell periphery", "extracellular region", "membrane")
row_group <- factor(row_group, levels = desired_order)
zscore_matrix <- zscore_matrix[order(row_group), ]
row_group <- row_group[order(row_group)]

# FPKM sample annotation
sample_names_fpkm <- colnames(zscore_matrix)
Condition_fpkm <- factor(
  ifelse(grepl("primary", sample_names_fpkm), "primary-insert",
         ifelse(grepl("tissue", sample_names_fpkm), "tissue", "organoid-insert")),
  levels = c("primary-insert", "tissue", "organoid-insert")
)

ha_col_fpkm <- HeatmapAnnotation(
  Condition = Condition_fpkm,
  col = list(Condition = c("primary-insert" = "#E41A1C", "tissue" = "#377EB8", "organoid-insert" = "#4DAF4A")),
  annotation_name_gp = gpar(fontsize = 18, fontface = "bold"),
  annotation_legend_param = list(
    title = "Condition",
    title_gp = gpar(fontsize = 18, fontface = "bold"),
    labels_gp = gpar(fontsize = 18),
    at = c("primary-insert", "tissue", "organoid-insert"),
    labels = c("primary-insert", "tissue", "organoid-insert")
  )
)

# Draw FPKM Z-score heatmap
jpeg("Heatmap_Log2FPKM_Zscore.jpg", width = 9200, height = 9200, res = 600)
Heatmap(zscore_matrix,
        name = "Z-score",
        col = colorRamp2(c(-2, 0, 2), c("blue", "white", "red")),
        cluster_rows = FALSE,
        cluster_columns = TRUE,
        row_split = row_group,
        row_gap = unit(4, "mm"),
        row_title_rot = 0,
        row_title_gp = gpar(fontsize = 20, fontface = "bold"),
        border = TRUE,
        show_row_names = FALSE,
        row_names_gp = gpar(fontsize = 18),
        column_names_gp = gpar(fontsize = 20),
        heatmap_legend_param = list(title = "Z-score", title_gp = gpar(fontsize = 16, fontface = "bold"), labels_gp = gpar(fontsize = 16)),
        top_annotation = ha_col_fpkm)
dev.off()
#----------------------------
# Export log2(FPKM) Z-score matrix with metadata
#----------------------------

# Reload FPKM to extract gene_id
fpkm_map <- read.csv("final_filtered_fpkm_values_with_gene_names.csv", row.names = 1)
fpkm_map$gene_name <- toupper(fpkm_map$gene_name)
fpkm_map$gene_id <- rownames(fpkm_map)
fpkm_map <- fpkm_map[!duplicated(fpkm_map$gene_name), ]

# Start export table
export_df <- as.data.frame(zscore_matrix)
export_df$Gene_Name <- rownames(export_df)

# Merge in pathway name
export_df <- merge(export_df, gene_pathway_map, by = "Gene_Name")

# Merge in gene_id
export_df <- merge(export_df, fpkm_map[, c("gene_name", "gene_id")], by.x = "Gene_Name", by.y = "gene_name")

# Add pathway ID if available
gsea_unique <- gsea[!duplicated(gsea$Gene_Name), c("Gene_Name", "Pathway_ID")]
export_df <- merge(export_df, gsea_unique, by = "Gene_Name", all.x = TRUE)

# Reorder columns: gene, IDs, pathway, Z-scores
z_cols <- colnames(zscore_matrix)
export_df <- export_df[, c("Gene_Name", "gene_id", "Pathway_Name", "Pathway_ID", z_cols)]

# Sort by pathway name (alphabetical or by biological grouping, depending on your earlier levels)
export_df <- export_df[order(factor(export_df$Pathway_Name, levels = desired_order)), ]

# Write to file
write.csv(export_df, "Zscores_Log2FPKM_with_metadata.csv", row.names = FALSE)

############    End of the Code  #############
